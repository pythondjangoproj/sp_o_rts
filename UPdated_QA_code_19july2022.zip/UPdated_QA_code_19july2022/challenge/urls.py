from django.urls import path
from challenge.views import UserChallengeAPI, UserChallengeResultAPI, DirectChallengeAPI, OpenChallengeAPI, CreateNewChallengeAPI, OpponentUserAPI
#from rest_framework import routers
#from challenge.views import ChallengeViewSet, ChallengeOutcomeViewSet

#router = routers.DefaultRouter()
#router.register(r'challenges', ChallengeViewSet)
#router.register(r'outcomes', ChallengeOutcomeViewSet)

urlpatterns = [
    path('challenge/<int:pk>/', UserChallengeAPI.as_view(), name='challenge'),
    path('challenge/', UserChallengeAPI.as_view(), name='challenge'),
    path('challenge_winner/', UserChallengeResultAPI.as_view(), name='challenge_winner'),
    path('challenge_winner/<int:pk>/', UserChallengeResultAPI.as_view(), name='challenge_winner'),
    path('direct_challenge/', DirectChallengeAPI.as_view(), name='direct_challenge'),
    path('direct_challenge/<int:pk>/', DirectChallengeAPI.as_view(), name='direct_challenge'),
    path('open_challenge/', OpenChallengeAPI.as_view(), name='open_challenge'),
    path('open_challenge/<int:pk>/', OpenChallengeAPI.as_view(), name='open_challenge'),
    path('new_challenge/', CreateNewChallengeAPI.as_view(), name='new_challenge'),
    path('new_challenge/<int:pk>/', CreateNewChallengeAPI.as_view(), name='new_challenge'),
    path('opponent/', OpponentUserAPI.as_view(), name='opponent'),
    path('opponent/<int:pk>/', OpponentUserAPI.as_view(), name='opponent'),

]
