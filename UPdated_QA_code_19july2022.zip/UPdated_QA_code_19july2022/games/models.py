"""Import required module"""
from django.db import models
from IGL_account.models import User
from autoslug import AutoSlugField
from iconApi.models import BaseModel
from iconApi.mixins import AuditTrailMixin, GuidFieldMixin, ApiMappableMixin
from icon.models import Icon


class Platform(BaseModel):
    """ A class is used to represent the Platform """
    name = models.CharField(max_length=255)
    manufacturer = models.CharField(max_length=255)
    model = models.CharField(max_length=255)

    def get_games(self):
        return Game.objects.filter(platforms=self)

    def __str__(self):
        return self.name


class Game(BaseModel,
           GuidFieldMixin):
    """ A class is used to represent the Game """
    display_name = models.CharField(max_length=255)
    slug = AutoSlugField(populate_from='full_name', unique=True)
    full_name = models.CharField(max_length=255)
    short_name = models.CharField(max_length=50)
    platforms = models.ManyToManyField(Platform)
    display_image = models.ImageField(default='call-of-duty.jpeg', upload_to='game_logos', blank=True, null=True)

    def get_platforms(self):
        return self.platforms.all()

    def __str__(self):
        return self.display_name


class Tournament(BaseModel,
                 AuditTrailMixin,
                 GuidFieldMixin,
                 ApiMappableMixin):
    """ A class is used to represent the Tournament """
    name = models.CharField(max_length=150, unique=True)
    full_name = models.CharField(max_length=255)
    slug = AutoSlugField(populate_from='full_name', unique_with='scheduled_date_start')
    game = models.ForeignKey(Game, on_delete=models.SET_NULL, null=True)
    size = models.PositiveSmallIntegerField()
    scheduled_date_start = models.DateField()
    scheduled_date_end = models.DateField()

    def __str__(self):
        return self.name


class StageType(BaseModel):
    """ A class is used to represent the StageType """
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Stage(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin,
            ApiMappableMixin):
    """ A class is used to represent the Stage """
    name = models.CharField(max_length=255)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    number = models.PositiveSmallIntegerField()
    stage_type = models.ForeignKey(StageType, blank=True, null=True, on_delete=models.SET_NULL)
    is_closed = models.BooleanField(default=False)

    def __str__(self):
        return "{0} - Stage {1}".format(self.tournament.name,
                                        self.name)


class Group(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin,
            ApiMappableMixin):
    """ A class is used to represent the Group """
    name = models.CharField(max_length=255)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    closed = models.BooleanField(default=False)

    def __str__(self):
        return "{0} - Group {1}".format(
            self.tournament.name,
            self.name,
        )


class Round(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin,
            ApiMappableMixin):
    """ A class is used to represent the Round """
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    stage = models.ForeignKey(Stage, on_delete=models.CASCADE, blank=True, null=True)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, blank=True, null=True)
    number = models.PositiveSmallIntegerField()

    start_datetime = models.DateTimeField(blank=True, null=True)
    end_datetime = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return "{0} - Stage {1} - Group {2} - Round {3}".format(
            self.tournament.name,
            self.stage.name,
            self.group.name,
            self.number
        )


class Match(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin,
            ApiMappableMixin):
    """ A class is used to represent the Match """

    class Meta:
        verbose_name_plural = 'Matches'

    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    round = models.ForeignKey(Round, on_delete=models.CASCADE, blank=True, null=True)
    stage = models.ForeignKey(Stage, on_delete=models.CASCADE, blank=True, null=True)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, blank=True, null=True)

    number = models.PositiveSmallIntegerField()
    scheduled_datetime = models.DateTimeField(blank=True, null=True)
    start_datetime = models.DateTimeField(blank=True, null=True)
    end_datetime = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return "{0} - Round {1} - Match {2}".format(self.tournament.name,
                                                    self.round.number,
                                                    self.number)


class MatchParticipant(BaseModel,
                       GuidFieldMixin,
                       ApiMappableMixin):
    """ A class is used to represent the MatchParticipant """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    match = models.ForeignKey(Match, on_delete=models.CASCADE)

    checked_in_at = models.DateTimeField()

    def __str__(self):
        return self.user.username


class TrophyCategory(BaseModel,
                     AuditTrailMixin,
                     GuidFieldMixin,
                     ApiMappableMixin):
    """ A class is used to represent the TrophyCategory """
    category_name = models.CharField(max_length=225)
    badges_image = models.ImageField(default='tournament.jpg', upload_to='badges_logos', blank=True, null=True)

    def __str__(self):
        return '%s, %s' % (self.category_name, self.badges_image)


class BadgesCategory(BaseModel,
                     AuditTrailMixin,
                     GuidFieldMixin,
                     ApiMappableMixin):
    """ A class is used to represent the TrophyCategory """
    category_id = models.ManyToManyField(TrophyCategory)
    badge_type = models.CharField(max_length=225)
    display_name = models.CharField(max_length=225)

    def __str__(self):
        return self.display_name


class Challenges(models.Model):
    """ A class is used to represent the TrophyCategory """
    wins20 = models.IntegerField(null=True, blank=True)
    wins50 = models.IntegerField(null=True, blank=True)
    wins100 = models.IntegerField(null=True, blank=True)
    wins20_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)
    wins50_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)
    wins100_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)


class Tournaments(models.Model):
    """ A class is used to represent the Tournaments """
    wins1 = models.IntegerField(null=True, blank=True)
    wins5 = models.IntegerField(null=True, blank=True)
    wins10 = models.IntegerField(null=True, blank=True)
    wins1_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)
    wins5_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)
    wins10_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)


class EarnedCoins(models.Model):
    """ A class is used to represent the EarnedCoins """
    earn500 = models.IntegerField(null=True, blank=True)
    earn1000 = models.IntegerField(null=True, blank=True)
    earn10000 = models.IntegerField(null=True, blank=True)
    earn500_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)
    earn1000_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)
    earn10000_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)


class Friends(models.Model):
    """ A class is used to represent the Friends """
    add5 = models.IntegerField(null=True, blank=True)
    add10 = models.IntegerField(null=True, blank=True)
    add20 = models.IntegerField(null=True, blank=True)
    add5_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)
    add10_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)
    add20_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)


class LoginStreak(models.Model):
    """ A class is used to represent the LoginStreak """
    log5 = models.IntegerField(null=True, blank=True, default=0)
    log10 = models.IntegerField(null=True, blank=True)
    log20 = models.IntegerField(null=True, blank=True)
    log5_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)
    log10_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)
    log20_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)


class UserBadges(models.Model):
    """ A class is used to represent the UserBadges """

    user_id = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    challenges = models.ForeignKey(Challenges, on_delete=models.CASCADE, blank=True, null=True)
    tournaments = models.ForeignKey(Tournaments, on_delete=models.CASCADE, blank=True, null=True)
    earned_coins = models.ForeignKey(EarnedCoins, on_delete=models.CASCADE, blank=True, null=True)
    Friend = models.ForeignKey(Friends, on_delete=models.CASCADE, blank=True, null=True)
    login_streak = models.ForeignKey(LoginStreak, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return str(self.user_id)

