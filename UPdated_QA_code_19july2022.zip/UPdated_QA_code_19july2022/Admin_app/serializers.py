"""Import required module"""
import logging
from rest_framework import serializers
from .models import TournamentSetupIn, TournamentFormate, TournamentLengthIn, MyTimezoneTableIn, AddIcon, BlogCategory, BlogPost, VideoManagement
from IGL_account.models import User

class AdminRegistrationSerializer(serializers.ModelSerializer):
    """ We are writing this because we need confirm password field in our registration Request """
    confirm_password = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'mobile_number', 'email', 'password','IGL_Username',
                  'confirm_password']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate(self, attrs):
        """ Validating Password and Confirm Password while Registration"""
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')
        if password != confirm_password:
            raise serializers.ValidationError("Password and Confirm Password doesn't match")
        logging.info('Information incoming!')
        return attrs

    def create(self, validate_data):
        return User.objects.create_admin(**validate_data)


class AdminLoginSerializer(serializers.ModelSerializer):
    """ A class AdminLoginSerializer Serializer is used for  AdminLogin Model """
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', 'password']


class UserOtpSerializer(serializers.ModelSerializer):
    """ create UserOtpSerializer for sending otp to mail"""
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', ]


class AdminProfileSerializer(serializers.ModelSerializer):
    """ create AdminProfileSerializer for serialized admin profile details"""
    groups = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your User Model fields"""
        model = User
        fields = ['id', 'last_login', 'is_superuser', 'is_staff', 'is_active', 'is_varified', 'date_joined', 'first_name', 'last_name',
                  'mobile_number', 'IGL_Username', 'email', 'terms_and_condition_agreement', 'code_of_conduct_agreement','profile_image', 'groups'] 

    def get_groups(self, group_obj):
        group = group_obj.groups.all()
        for name in group:
            return str(name)


class TournamentFormateSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentFormate
        fields = ('id', 'type')


class MyTableZoneSerializer(serializers.ModelSerializer):

    class Meta:
        model = MyTimezoneTableIn
        fields = ('id', 'tz_name')


class TournamentLengthSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentLengthIn
        fields = ('id', 'hour')


class TournamentSetupSerializers(serializers.ModelSerializer):
    tournament_host = serializers.StringRelatedField()
    platform = serializers.StringRelatedField(many=True)
    game = serializers.StringRelatedField(many=True)
    tournament_structure = serializers.StringRelatedField()
    tournament_open_to = serializers.StringRelatedField()

    class Meta:
        model = TournamentSetupIn
        fields = '__all__'

class TournamentSetupSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentSetupIn
        fields = '__all__'


class AddIconSerializers(serializers.ModelSerializer):
    """ A class AddIconSerializer Serializer is used for AddIcon module for GET method"""

    games = serializers.StringRelatedField(many=True,)
    platform = serializers.StringRelatedField()

    class Meta:
        model = AddIcon
        fields = '__all__'


class AddIconSerializer(serializers.ModelSerializer):
    """ A class AddIconSerializer Serializer is used for AddIcon module POST method"""

    class Meta:
        model = AddIcon
        fields = '__all__'


class BlogCategorySerializer(serializers.ModelSerializer):
    """ A class BlogCategorySerializer Serializer is used for Blog category method"""

    class Meta:
        model = BlogCategory
        fields = ('id', 'category')


class BlogPostSerializer(serializers.ModelSerializer):
    """ A class BlogPostSerializer Serializer is used for Blog Post module"""

    class Meta:
        model = BlogPost
        fields = '__all__'


class VideoManagementSerializer(serializers.ModelSerializer):
    """ A class BlogPostSerializer Serializer is used for Blog Post module"""

    class Meta:
        model = VideoManagement
        fields = '__all__'
