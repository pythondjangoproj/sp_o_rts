""" import required module """
import uuid
from django.db import models


class BaseModel(models.Model):
    id = models.AutoField(
        primary_key=True,
        unique=True,
        editable=False
    )

    class Meta:
        abstract = True


class BaseTimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class BaseUserMetadataModel(models.Model):
    created_by = models.EmailField()
    updated_by = models.EmailField()

    class Meta:
        abstract = True


class BaseGuidModel(models.Model):
    guid = models.UUIDField(default=uuid.uuid4, editable=False)

    class Meta:
        abstract = True


class BaseApiMappableModel(models.Model):
    object_id = models.CharField(max_length=150, blank=True, null=True)

    class Meta:
        abstract = True


class NameDescriptionModel(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)

    class Meta:
        abstract = True
