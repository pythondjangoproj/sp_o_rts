""" import required """
from IGL_account.models import User
from rest_framework import serializers
from .models import Icon, IconTeam, IconTeamMember
from iconApi.settings.default import base_url


class IconSerializer(serializers.ModelSerializer):
    """ A class IconSerializer Serializer is used for  Icon Model """
    display_image = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your   Tournament Model fields"""
        model = Icon
        fields = (
            'id', 'first_name', 'last_name', 'display_name', 'display_image', 'user',)

    def get_display_image(self, obj):
        if obj:
            a = base_url + obj.display_image.url
            return a
        return ''


class IconTeamSerializer(serializers.ModelSerializer):
    """ A class IconTeamSerializer Serializer is used for  Icon Model """
    display_image = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your IconTeam Model fields"""
        model = IconTeam
        fields = (
            'id', 'icon', 'team_name', 'display_image',)

    def get_display_image(self, obj):
        if obj:
            a = base_url + obj.display_image.url
            return a
        return ''


class IconTeamMemberSerializer(serializers.ModelSerializer):
    """ A class IconTeamMemberSerializer  Serializer is used for  IconTeamMember Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your IconTeamMember Model fields"""
        model = IconTeamMember
        fields = (
            "id", "user", 'team', 'joined_at', 'left_at',)
