from django.urls import path
# from django.conf.urls import url
from .views import sample, test_payment, save_stripe_info

urlpatterns = [
    path(r'sample', sample, name="Sample"),
    path(r'test-payment', test_payment, name="test_payment"),
    path(r'save-stripe-info', save_stripe_info),
]

